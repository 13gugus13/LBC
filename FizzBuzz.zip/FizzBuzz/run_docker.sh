#!/bin/bash

#Build jar
./gradlew clean build

#remove old container
docker rm -f fizzbuzz

#Build docker image
docker build -t fizzbuzz .

#Run docker container
docker run -d -p 8080:8080 --name fizzbuzz fizzbuzz