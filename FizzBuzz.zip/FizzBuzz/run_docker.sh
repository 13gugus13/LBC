#!/bin/bash

#Build jar
./gradlew clean build

docker build -t fizzbuzz .

docker run -d -p 8080:8080 --name fizzbuzz fizzbuzz