package com.lbc.fizzbuzz.controllers.request;

import java.util.ArrayList;

public record FizzBuzzRequest (
        Integer int1,
        Integer int2,
        Integer limit,
        String str1,
        String str2
) {
    public boolean isValid() {
        return int1 != null && int1 != 0 &&
                int2 != null && int2 != 0 &&
                limit != null && limit != 0 &&
                str1 != null && !str1.isEmpty()
                && str2 != null &&  !str2.isEmpty();
    }

    public String getErrorMessage() {
        var errors =new ArrayList<String>();
        if (int1 == null || int1 == 0) {
            errors.add("int1 is required and must be different than 0");
        }
        if (int2 == null || int2 == 0) {
            errors.add("int2 is required and must be different than 0");
        }
        if (limit == null || limit == 0) {
            errors.add("limit is required and must be different than 0");
        }
        if (str1 == null || str1.isEmpty()) {
            errors.add("str1 is required and must not be empty");
        }
        if (str2 == null || str2.isEmpty()) {
            errors.add("str2 is required and must not be empty");
        }
        return String.join(", ", errors);
    }

}
