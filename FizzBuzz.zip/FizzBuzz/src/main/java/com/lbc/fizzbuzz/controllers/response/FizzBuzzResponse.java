package com.lbc.fizzbuzz.controllers.response;

import lombok.EqualsAndHashCode;

import java.util.List;

public record FizzBuzzResponse (List<String> result) {
}
