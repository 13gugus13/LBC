package com.lbc.fizzbuzz.services;

import com.lbc.fizzbuzz.controllers.request.FizzBuzzRequest;
import com.lbc.fizzbuzz.controllers.response.FizzBuzzStatResponse;
import com.lbc.fizzbuzz.controllers.response.FizzBuzzResponse;

public interface FizzBuzzService {

    FizzBuzzResponse getFizzBuzzList(FizzBuzzRequest fizzBuzzRequest);

    FizzBuzzStatResponse getMostUsed();


}
