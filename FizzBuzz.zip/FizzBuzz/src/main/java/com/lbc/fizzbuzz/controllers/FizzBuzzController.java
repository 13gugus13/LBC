package com.lbc.fizzbuzz.controllers;


import com.lbc.fizzbuzz.controllers.request.FizzBuzzRequest;
import com.lbc.fizzbuzz.controllers.response.FizzBuzzStatResponse;
import com.lbc.fizzbuzz.controllers.response.FizzBuzzResponse;
import com.lbc.fizzbuzz.services.FizzBuzzService;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class FizzBuzzController {


    private final FizzBuzzService fizzBuzzService;

    public FizzBuzzController(FizzBuzzService fizzBuzzService) {
        this.fizzBuzzService = fizzBuzzService;
    }


    @PostMapping("/fizzbuzz")
    public ResponseEntity<FizzBuzzResponse> getFizzBuzzList(@RequestBody @Validated FizzBuzzRequest fizzBuzzRequest) {
        try {
            return ResponseEntity.ok(fizzBuzzService.getFizzBuzzList(fizzBuzzRequest));
        }catch (IllegalArgumentException e){
            return ResponseEntity.badRequest().body(new FizzBuzzResponse(List.of(e.getMessage())));
        }
    }

    @GetMapping("/fizzbuzz/stats")
    public ResponseEntity<FizzBuzzStatResponse> getFizzBuzzStats() {
        var response = fizzBuzzService.getMostUsed();
        if (response == null) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(response);
    }

}
