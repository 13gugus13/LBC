package com.lbc.fizzbuzz.mappers;

public interface BaseMapperInterface<T, U> {
    U map(T t);
}
