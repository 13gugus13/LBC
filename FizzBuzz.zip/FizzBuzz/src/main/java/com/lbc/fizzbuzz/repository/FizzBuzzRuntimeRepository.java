package com.lbc.fizzbuzz.repository;

import com.lbc.fizzbuzz.controllers.response.FizzBuzzStatResponse;
import com.lbc.fizzbuzz.model.FizzBuzz;
import com.lbc.fizzbuzz.model.FizzBuzzStats;
import org.springframework.stereotype.Repository;

import java.util.*;

@Repository
public class FizzBuzzRuntimeRepository implements FizzBuzzRepository {


    private final List<FizzBuzzStats> fizzBuzzStatsList;

    public FizzBuzzRuntimeRepository() {
        fizzBuzzStatsList = new ArrayList<>();
    }

    @Override
    public void save(FizzBuzz fizzBuzz) {
            fizzBuzzStatsList.stream()
                    .filter(fizzBuzzStats -> fizzBuzzStats.getParams().equals(fizzBuzz))
                    .findFirst()
                    .ifPresentOrElse(
                            fizzBuzzStats -> fizzBuzzStats.setCount(fizzBuzzStats.getCount() + 1),
                            () -> fizzBuzzStatsList.add(new FizzBuzzStats(fizzBuzz, 1))
                    );
    }

    @Override
    public Optional<FizzBuzzStats> getMostUsed() {
        return fizzBuzzStatsList.stream()
                .max(Comparator.comparing(FizzBuzzStats::getCount));
    }







}
