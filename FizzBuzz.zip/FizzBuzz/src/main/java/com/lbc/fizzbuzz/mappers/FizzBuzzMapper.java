package com.lbc.fizzbuzz.mappers;


import com.lbc.fizzbuzz.controllers.request.FizzBuzzRequest;
import com.lbc.fizzbuzz.model.FizzBuzz;
import org.springframework.stereotype.Component;

@Component
public class FizzBuzzMapper implements BaseMapperInterface<FizzBuzzRequest, FizzBuzz> {

    @Override
    public FizzBuzz map(FizzBuzzRequest request){
        return new FizzBuzz(request.int1(), request.int2(), request.limit(), request.str1(), request.str2());
    }


}
