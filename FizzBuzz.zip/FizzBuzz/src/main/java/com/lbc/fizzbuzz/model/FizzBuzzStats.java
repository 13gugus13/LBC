package com.lbc.fizzbuzz.model;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import java.util.Objects;

@Getter
public class FizzBuzzStats {

    private FizzBuzz params;

    @Setter
    private Integer count;

    public FizzBuzzStats(FizzBuzz fizzBuzz, Integer count) {
        this.params = fizzBuzz;
        this.count = count;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        FizzBuzzStats that = (FizzBuzzStats) o;
        return Objects.equals(params, that.params) && Objects.equals(count, that.count);
    }

    @Override
    public int hashCode() {
        return Objects.hash(params, count);
    }
}
