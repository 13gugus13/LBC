package com.lbc.fizzbuzz.model;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import java.util.List;
import java.util.Objects;

@Getter
public class FizzBuzz {
    private final Integer int1;
    private final Integer int2;
    private final Integer limit;
    private final String str1;
    private final String str2;


    @Setter
    private List<String> result;

    public FizzBuzz(Integer int1, Integer int2, Integer limit, String str1, String str2) {
        this.int1 = int1;
        this.int2 = int2;
        this.limit = limit;
        this.str1 = str1;
        this.str2 = str2;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        FizzBuzz fizzBuzz = (FizzBuzz) o;
        return Objects.equals(int1, fizzBuzz.int1) && Objects.equals(int2, fizzBuzz.int2) && Objects.equals(limit, fizzBuzz.limit) && Objects.equals(str1, fizzBuzz.str1) && Objects.equals(str2, fizzBuzz.str2) && Objects.equals(result, fizzBuzz.result);
    }

    @Override
    public int hashCode() {
        return Objects.hash(int1, int2, limit, str1, str2, result);
    }
}
