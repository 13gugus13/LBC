package com.lbc.fizzbuzz.repository;

import com.lbc.fizzbuzz.controllers.response.FizzBuzzStatResponse;
import com.lbc.fizzbuzz.model.FizzBuzz;
import com.lbc.fizzbuzz.model.FizzBuzzStats;

import java.util.Optional;

public interface FizzBuzzRepository {
    void save(FizzBuzz fizzBuzz);

    Optional<FizzBuzzStats> getMostUsed();
}
