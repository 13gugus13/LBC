package com.lbc.fizzbuzz.mappers;

import com.lbc.fizzbuzz.controllers.response.FizzBuzzStatResponse;
import com.lbc.fizzbuzz.model.FizzBuzzStats;
import org.springframework.stereotype.Component;

@Component
public class FizzBuzzStatsMapper implements BaseMapperInterface<FizzBuzzStats, FizzBuzzStatResponse> {

    @Override
    public FizzBuzzStatResponse map(FizzBuzzStats fizzBuzzStats) {
        return new FizzBuzzStatResponse(fizzBuzzStats.getParams().getInt1(), fizzBuzzStats.getParams().getInt2(), fizzBuzzStats.getParams().getLimit(), fizzBuzzStats.getParams().getStr1(), fizzBuzzStats.getParams().getStr2(), fizzBuzzStats.getCount());
    }
}
