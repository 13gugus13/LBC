package com.lbc.fizzbuzz.services.implementation;

import com.lbc.fizzbuzz.controllers.request.FizzBuzzRequest;
import com.lbc.fizzbuzz.controllers.response.FizzBuzzStatResponse;
import com.lbc.fizzbuzz.controllers.response.FizzBuzzResponse;
import com.lbc.fizzbuzz.mappers.FizzBuzzMapper;
import com.lbc.fizzbuzz.mappers.FizzBuzzStatsMapper;
import com.lbc.fizzbuzz.repository.FizzBuzzRepository;
import com.lbc.fizzbuzz.services.FizzBuzzService;
import lombok.NonNull;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class FizzBuzzServiceImplementation implements FizzBuzzService {

    private final FizzBuzzRepository fizzBuzzRepository;

    private final FizzBuzzMapper fizzBuzzMapper;

    private final FizzBuzzStatsMapper fizzBuzzStatsMapper;

    public FizzBuzzServiceImplementation(FizzBuzzRepository fizzBuzzRepository, FizzBuzzMapper fizzBuzzMapper, FizzBuzzStatsMapper fizzBuzzStatsMapper) {
        this.fizzBuzzRepository = fizzBuzzRepository;
        this.fizzBuzzMapper = fizzBuzzMapper;
        this.fizzBuzzStatsMapper = fizzBuzzStatsMapper;
    }

    @Override
    public FizzBuzzResponse getFizzBuzzList(@NonNull FizzBuzzRequest fizzBuzzRequest) {
        var dto = fizzBuzzMapper.map(fizzBuzzRequest);
        if( !fizzBuzzRequest.isValid()){
            dto.setResult(null);
            fizzBuzzRepository.save(dto);
            throw new IllegalArgumentException(fizzBuzzRequest.getErrorMessage());
        }
        var res = fizzBuzz(dto.getInt1(), dto.getInt2(), dto.getLimit(), dto.getStr1(), dto.getStr2());
        dto.setResult(res);
        fizzBuzzRepository.save(dto);
        return new FizzBuzzResponse(res);
    }


    private final List<String> fizzBuzz(int int1, int int2, int limit, String str1, String str2) {
        List<String> result = new ArrayList<>();
        if(limit < 0) {
            for (int i = -1; i >= limit; i--) {
                result.add(processItem(i, int1, int2, str1, str2));
            }
        }else {
            for (int i = 1; i <= limit; i++) {
                result.add(processItem(i, int1, int2, str1, str2));
            }
        }
        return result;
    }

    private String processItem(int i, int int1, int int2, String str1, String str2){
        if(i % int1 == 0 && i % int2 == 0){
            return str1 + str2;
        }
        if(i % int1 == 0){
            return str1;
        }
        if(i % int2 == 0){
            return str2;
        }
        return String.valueOf(i);
    }

    @Override
    public FizzBuzzStatResponse getMostUsed() {
        var res = fizzBuzzRepository.getMostUsed();
        return res.map(fizzBuzzStatsMapper::map).orElse(null);
    }


}
