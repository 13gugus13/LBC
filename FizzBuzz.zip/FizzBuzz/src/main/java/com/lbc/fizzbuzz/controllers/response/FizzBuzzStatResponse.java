package com.lbc.fizzbuzz.controllers.response;


public record FizzBuzzStatResponse (Integer int1, Integer int2, Integer limit, String str1, String str2, Integer count)
{
}
