package com.lbc.fizzbuzz;

import com.lbc.fizzbuzz.controllers.request.FizzBuzzRequest;
import com.lbc.fizzbuzz.controllers.response.FizzBuzzResponse;
import com.lbc.fizzbuzz.controllers.response.FizzBuzzStatResponse;
import com.lbc.fizzbuzz.model.FizzBuzz;
import com.lbc.fizzbuzz.model.FizzBuzzStats;

import java.util.List;

public class FizzBuzzTests {

    protected final FizzBuzzRequest valid = new FizzBuzzRequest(2, 3, 6, "Fizz", "Buzz");
    protected final FizzBuzz validFizzBuzz = new FizzBuzz(2, 3, 6, "Fizz", "Buzz");
    protected final FizzBuzzResponse validRequestResponse = new FizzBuzzResponse(List.of("1", "Fizz", "Buzz", "Fizz", "5", "FizzBuzz"));
    protected final FizzBuzzStats validStats = new FizzBuzzStats(validFizzBuzz, 1);
    protected final FizzBuzzStatResponse validStatsResponse = new FizzBuzzStatResponse(valid.int1(), valid.int2(), valid.limit(), valid.str1(), valid.str2(), 1);


    protected final FizzBuzzRequest invalidInt1 = new FizzBuzzRequest(0, 2, 2, "Fizz", "Buzz");
    protected final FizzBuzz invalidInt1FizzBuzz = new FizzBuzz(0, 2, 2, "Fizz", "Buzz");
    protected final FizzBuzzResponse invalidInt1Response = new FizzBuzzResponse(List.of("int1 is required and must be different than 0"));

    protected final FizzBuzzStats invalidInt1Stats = new FizzBuzzStats(invalidInt1FizzBuzz, 1);

    protected final FizzBuzzStatResponse invalidInt1StatsResponse = new FizzBuzzStatResponse(invalidInt1.int1(), invalidInt1.int2(), invalidInt1.limit(), invalidInt1.str1(), invalidInt1.str2(), 1);


    protected final FizzBuzzRequest invalidInt2 = new FizzBuzzRequest(2, 0, 2, "Fizz", "Buzz");

    protected final FizzBuzz invalidInt2FizzBuzz = new FizzBuzz(2, 0, 2, "Fizz", "Buzz");
    protected final FizzBuzzResponse invalidInt2Response = new FizzBuzzResponse(List.of("int2 is required and must be different than 0"));

    protected final FizzBuzzStats invalidInt2Stats = new FizzBuzzStats(invalidInt2FizzBuzz, 1);

    protected final FizzBuzzStatResponse invalidInt2StatsResponse = new FizzBuzzStatResponse(invalidInt2.int1(), invalidInt2.int2(), invalidInt2.limit(), invalidInt2.str1(), invalidInt2.str2(), 1);


    protected final FizzBuzzRequest invalidLimit = new FizzBuzzRequest(2, 2, 0, "Fizz", "Buzz");
    protected final FizzBuzz invalidLimitFizzBuzz = new FizzBuzz(2, 2, 0, "Fizz", "Buzz");
    protected final FizzBuzzResponse invalidLimitResponse = new FizzBuzzResponse(List.of("limit is required and must be different than 0"));

    protected final FizzBuzzStatResponse invalidLimitStatsResponse = new FizzBuzzStatResponse(invalidLimit.int1(), invalidLimit.int2(), invalidLimit.limit(), invalidLimit.str1(), invalidLimit.str2(), 1);

    protected final FizzBuzzStats invalidLimitStats = new FizzBuzzStats(invalidLimitFizzBuzz, 1);


    protected final FizzBuzzRequest invalidStr1 = new FizzBuzzRequest(2, 2, 2, "", "Buzz");

    protected final FizzBuzz invalidStr1FizzBuzz = new FizzBuzz(2, 2, 2, "", "Buzz");
    protected final FizzBuzzResponse invalidStr1Response = new FizzBuzzResponse(List.of("str1 is required and must not be empty"));

    protected final FizzBuzzStats invalidStr1Stats = new FizzBuzzStats(invalidStr1FizzBuzz, 1);

    protected final FizzBuzzStatResponse invalidStr1StatsResponse = new FizzBuzzStatResponse(invalidStr1.int1(), invalidStr1.int2(), invalidStr1.limit(), invalidStr1.str1(), invalidStr1.str2(), 1);


    protected final FizzBuzzRequest invalidStr2 = new FizzBuzzRequest(2, 2, 2, "Fizz", "");

    protected final FizzBuzz invalidStr2FizzBuzz = new FizzBuzz(2, 2, 2, "Fizz", "");
    protected final FizzBuzzResponse invalidStr2Response = new FizzBuzzResponse(List.of("str2 is required and must not be empty"));

    protected final FizzBuzzStats invalidStr2Stats = new FizzBuzzStats(invalidStr2FizzBuzz, 1);

    protected final FizzBuzzStatResponse invalidStr2StatsResponse = new FizzBuzzStatResponse(invalidStr2.int1(), invalidStr2.int2(), invalidStr2.limit(), invalidStr2.str1(), invalidStr2.str2(), 1);

    protected final FizzBuzzRequest allInvalid = new FizzBuzzRequest(null, null, null, null, null);

    protected final FizzBuzz invalidAllFizzBuzz = new FizzBuzz(null, null, null, null, null);
    protected final FizzBuzzResponse allInvalidResponse = new FizzBuzzResponse(List.of("int1 is required and must be different than 0, int2 is required and must be different than 0, limit is required and must be different than 0, str1 is required and must not be empty, str2 is required and must not be empty"));

    protected final FizzBuzzStats allInvalidStats = new FizzBuzzStats(invalidAllFizzBuzz, 1);

    protected final FizzBuzzStatResponse allInvalidStatsResponse = new FizzBuzzStatResponse(allInvalid.int1(), allInvalid.int2(), allInvalid.limit(), allInvalid.str1(), allInvalid.str2(), 1);

}
