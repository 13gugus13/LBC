package com.lbc.fizzbuzz.services.implementation;

import com.lbc.fizzbuzz.FizzBuzzTests;
import com.lbc.fizzbuzz.mappers.FizzBuzzMapper;
import com.lbc.fizzbuzz.mappers.FizzBuzzStatsMapper;
import com.lbc.fizzbuzz.repository.FizzBuzzRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class FizzBuzzServiceImplementationTest extends FizzBuzzTests {


    @Mock
    private FizzBuzzStatsMapper fizzBuzzStatsMapper;

    @Mock
    private FizzBuzzMapper fizzBuzzMapper;

    @Mock
    private FizzBuzzRepository fizzBuzzRepository;

    private FizzBuzzServiceImplementation fizzBuzzServiceImplementation;


    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        fizzBuzzServiceImplementation = new FizzBuzzServiceImplementation(fizzBuzzRepository, fizzBuzzMapper, fizzBuzzStatsMapper);


    }


    @Test
    void getFizzBuzzList() {
        when(fizzBuzzMapper.map(valid)).thenReturn(validFizzBuzz);
        assertEquals(validRequestResponse, fizzBuzzServiceImplementation.getFizzBuzzList(valid));
        verify(fizzBuzzRepository, times(1)).save(validFizzBuzz);
        verify(fizzBuzzMapper, times(1)).map(valid);


        when(fizzBuzzMapper.map(invalidInt1)).thenReturn(invalidInt1FizzBuzz);
        assertThrows(IllegalArgumentException.class, () -> fizzBuzzServiceImplementation.getFizzBuzzList(invalidInt1));
        verify(fizzBuzzRepository, times(1)).save(invalidInt1FizzBuzz);
        verify(fizzBuzzMapper, times(1)).map(invalidInt1);


        when(fizzBuzzMapper.map(invalidInt2)).thenReturn(invalidInt2FizzBuzz);
        assertThrows(IllegalArgumentException.class, () -> fizzBuzzServiceImplementation.getFizzBuzzList(invalidInt2));
        verify(fizzBuzzRepository, times(1)).save(invalidInt2FizzBuzz);
        verify(fizzBuzzMapper, times(1)).map(invalidInt2);

        when(fizzBuzzMapper.map(invalidLimit)).thenReturn(invalidLimitFizzBuzz);
        assertThrows(IllegalArgumentException.class, () -> fizzBuzzServiceImplementation.getFizzBuzzList(invalidLimit));
        verify(fizzBuzzRepository, times(1)).save(invalidLimitFizzBuzz);
        verify(fizzBuzzMapper, times(1)).map(invalidLimit);

        when(fizzBuzzMapper.map(invalidStr1)).thenReturn(invalidStr1FizzBuzz);
        assertThrows(IllegalArgumentException.class, () -> fizzBuzzServiceImplementation.getFizzBuzzList(invalidStr1));
        verify(fizzBuzzRepository, times(1)).save(invalidStr1FizzBuzz);
        verify(fizzBuzzMapper, times(1)).map(invalidStr1);

        when(fizzBuzzMapper.map(invalidStr2)).thenReturn(invalidStr2FizzBuzz);
        assertThrows(IllegalArgumentException.class, () -> fizzBuzzServiceImplementation.getFizzBuzzList(invalidStr2));
        verify(fizzBuzzRepository, times(1)).save(invalidStr2FizzBuzz);
        verify(fizzBuzzMapper, times(1)).map(invalidStr2);

        when(fizzBuzzMapper.map(allInvalid)).thenReturn(invalidAllFizzBuzz);
        assertThrows(IllegalArgumentException.class, () -> fizzBuzzServiceImplementation.getFizzBuzzList(allInvalid));
        verify(fizzBuzzRepository, times(1)).save(invalidAllFizzBuzz);
        verify(fizzBuzzMapper, times(1)).map(allInvalid);


    }

    @Test
    void getMostUsed() {
        when(fizzBuzzRepository.getMostUsed()).thenReturn(Optional.of(validStats));
        when(fizzBuzzStatsMapper.map(validStats)).thenReturn(validStatsResponse);
        assertEquals(validStatsResponse, fizzBuzzServiceImplementation.getMostUsed());
        when(fizzBuzzRepository.getMostUsed()).thenReturn(Optional.empty());
        assertNull(fizzBuzzServiceImplementation.getMostUsed());
    }
}