package com.lbc.fizzbuzz.mappers;

import com.lbc.fizzbuzz.FizzBuzzTests;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;


class FizzBuzzMapperTest extends FizzBuzzTests {

    private final FizzBuzzMapper fizzBuzzMapper = new FizzBuzzMapper();



   @Test
    void mapFizzBuzz() {
       assertEquals(validFizzBuzz, fizzBuzzMapper.map(valid));
       assertEquals(invalidInt1FizzBuzz, fizzBuzzMapper.map(invalidInt1));
       assertEquals(invalidInt2FizzBuzz, fizzBuzzMapper.map(invalidInt2));
       assertEquals(invalidLimitFizzBuzz, fizzBuzzMapper.map(invalidLimit));
       assertEquals(invalidStr1FizzBuzz, fizzBuzzMapper.map(invalidStr1));
       assertEquals(invalidStr2FizzBuzz, fizzBuzzMapper.map(invalidStr2));
       assertEquals(invalidAllFizzBuzz, fizzBuzzMapper.map(allInvalid));
    }
}