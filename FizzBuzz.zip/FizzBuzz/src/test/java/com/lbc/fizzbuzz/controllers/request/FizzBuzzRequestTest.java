package com.lbc.fizzbuzz.controllers.request;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class FizzBuzzRequestTest {

    @Test
    void isValid() {
        var request = new FizzBuzzRequest(3, 5, 15, "Fizz", "Buzz");
        assertTrue(request.isValid());
        request = new FizzBuzzRequest(0, 5, 15, "Fizz", "Buzz");
        assertFalse(request.isValid());
        request = new FizzBuzzRequest(3, 0, 15, "Fizz", "Buzz");
        assertFalse(request.isValid());
        request = new FizzBuzzRequest(3, 5, 0, "Fizz", "Buzz");
        assertFalse(request.isValid());
        request = new FizzBuzzRequest(3, 5, 15, "", "Buzz");
        assertFalse(request.isValid());
        request = new FizzBuzzRequest(3, 5, 15, "Fizz", "");
        assertFalse(request.isValid());
        request = new FizzBuzzRequest(null, 5, 15, "Fizz", "Buzz");
        assertFalse(request.isValid());
        request = new FizzBuzzRequest(3, null, 15, "Fizz", "Buzz");
        assertFalse(request.isValid());
        request = new FizzBuzzRequest(3, 5, null, "Fizz", "Buzz");
        assertFalse(request.isValid());
        request = new FizzBuzzRequest(3, 5, 15, null, "Buzz");
        assertFalse(request.isValid());
        request = new FizzBuzzRequest(3, 5, 15, "Fizz", null);
        assertFalse(request.isValid());
    }

    @Test
    void getErrorMessage() {
        var request = new FizzBuzzRequest(3, 5, 15, "Fizz", "Buzz");
        assertEquals("", request.getErrorMessage());
        request = new FizzBuzzRequest(0, 5, 15, "Fizz", "Buzz");
        assertEquals("int1 is required and must be different than 0", request.getErrorMessage());
        request = new FizzBuzzRequest(3, 0, 15, "Fizz", "Buzz");
        assertEquals("int2 is required and must be different than 0", request.getErrorMessage());
        request = new FizzBuzzRequest(3, 5, 0, "Fizz", "Buzz");
        assertEquals("limit is required and must be different than 0", request.getErrorMessage());
        request = new FizzBuzzRequest(3, 5, 15, "", "Buzz");
        assertEquals("str1 is required and must not be empty", request.getErrorMessage());
        request = new FizzBuzzRequest(3, 5, 15, "Fizz", "");
        assertEquals("str2 is required and must not be empty", request.getErrorMessage());
        request = new FizzBuzzRequest(null, 5, 15, "Fizz", "Buzz");
        assertEquals("int1 is required and must be different than 0", request.getErrorMessage());
        request = new FizzBuzzRequest(3, null, 15, "Fizz", "Buzz");
        assertEquals("int2 is required and must be different than 0", request.getErrorMessage());
        request = new FizzBuzzRequest(3, 5, null, "Fizz", "Buzz");
        assertEquals("limit is required and must be different than 0", request.getErrorMessage());
        request = new FizzBuzzRequest(3, 5, 15, null, "Buzz");
        assertEquals("str1 is required and must not be empty", request.getErrorMessage());
        request = new FizzBuzzRequest(3, 5, 15, "Fizz", null);
        assertEquals("str2 is required and must not be empty", request.getErrorMessage());
        request = new FizzBuzzRequest(0, 0, 0, "", "");
        assertEquals("int1 is required and must be different than 0, int2 is required and must be different than 0, limit is required and must be different than 0, str1 is required and must not be empty, str2 is required and must not be empty", request.getErrorMessage());
    }
}