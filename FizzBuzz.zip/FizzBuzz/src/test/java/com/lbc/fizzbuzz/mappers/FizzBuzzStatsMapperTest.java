package com.lbc.fizzbuzz.mappers;

import com.lbc.fizzbuzz.FizzBuzzTests;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class FizzBuzzStatsMapperTest extends FizzBuzzTests {

    private final FizzBuzzStatsMapper fizzBuzzStatsMapper = new FizzBuzzStatsMapper();

    @Test
    void map() {
        assertEquals(validStatsResponse, fizzBuzzStatsMapper.map(validStats));
        assertEquals(invalidInt1StatsResponse, fizzBuzzStatsMapper.map(invalidInt1Stats));
        assertEquals(invalidInt2StatsResponse, fizzBuzzStatsMapper.map(invalidInt2Stats));
        assertEquals(invalidLimitStatsResponse, fizzBuzzStatsMapper.map(invalidLimitStats));
        assertEquals(invalidStr1StatsResponse, fizzBuzzStatsMapper.map(invalidStr1Stats));
        assertEquals(invalidStr2StatsResponse, fizzBuzzStatsMapper.map(invalidStr2Stats));
        assertEquals(allInvalidStatsResponse, fizzBuzzStatsMapper.map(allInvalidStats));
    }

}