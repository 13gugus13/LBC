package com.lbc.fizzbuzz.repository;

import com.lbc.fizzbuzz.FizzBuzzTests;
import org.junit.jupiter.api.Test;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

class FizzBuzzRuntimeRepositoryTest extends FizzBuzzTests {

    private final FizzBuzzRuntimeRepository fizzBuzzRuntimeRepository = new FizzBuzzRuntimeRepository();


    @Test
    void save() {
        //Check that result is empty if no call has been made
        assertEquals(Optional.empty(), fizzBuzzRuntimeRepository.getMostUsed());
        fizzBuzzRuntimeRepository.save(validFizzBuzz);
        //Check that result is not empty after a call has been made and that the count is 1
        assertEquals(validStats.getCount(), fizzBuzzRuntimeRepository.getMostUsed().get().getCount());
        fizzBuzzRuntimeRepository.save(validFizzBuzz);
        //Check that the count has increased after second call on same object
        assertNotEquals(validStats.getCount(), fizzBuzzRuntimeRepository.getMostUsed().get().getCount());
        assertEquals(2, fizzBuzzRuntimeRepository.getMostUsed().get().getCount());
        for (int i = 0; i < 10; i++) {
            fizzBuzzRuntimeRepository.save(invalidInt1FizzBuzz);
        }
        invalidInt1Stats.setCount(10);
        //Check that the value return is now invalidInt1FizzBuzz and count is 10
        assertEquals(invalidInt1Stats.getCount(), fizzBuzzRuntimeRepository.getMostUsed().get().getCount());

        assertEquals(invalidInt1Stats, fizzBuzzRuntimeRepository.getMostUsed().get());
    }
}