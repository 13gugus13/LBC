package com.lbc.fizzbuzz.controllers;

import com.lbc.fizzbuzz.FizzBuzzTests;
import com.lbc.fizzbuzz.controllers.response.FizzBuzzResponse;
import com.lbc.fizzbuzz.controllers.response.FizzBuzzStatResponse;
import com.lbc.fizzbuzz.services.FizzBuzzService;
import com.lbc.fizzbuzz.services.implementation.FizzBuzzServiceImplementation;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatusCode;
import org.springframework.test.context.bean.override.mockito.MockitoBean;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

class FizzBuzzControllerTest extends FizzBuzzTests {

    @Mock
    private FizzBuzzService fizzBuzzService;

    private FizzBuzzController fizzBuzzController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        fizzBuzzController = new FizzBuzzController(fizzBuzzService);
        when(fizzBuzzService.getFizzBuzzList(invalidInt1)).thenThrow(new IllegalArgumentException("int1 is required and must be different than 0"));
        when(fizzBuzzService.getFizzBuzzList(invalidInt2)).thenThrow(new IllegalArgumentException("int2 is required and must be different than 0"));
        when(fizzBuzzService.getFizzBuzzList(invalidLimit)).thenThrow(new IllegalArgumentException("limit is required and must be different than 0"));
        when(fizzBuzzService.getFizzBuzzList(invalidStr1)).thenThrow(new IllegalArgumentException("str1 is required and must not be empty"));
        when(fizzBuzzService.getFizzBuzzList(invalidStr2)).thenThrow(new IllegalArgumentException("str2 is required and must not be empty"));
        when(fizzBuzzService.getFizzBuzzList(allInvalid)).thenThrow(new IllegalArgumentException("int1 is required and must be different than 0, int2 is required and must be different than 0, limit is required and must be different than 0, str1 is required and must not be empty, str2 is required and must not be empty"));
        when(fizzBuzzService.getFizzBuzzList(valid)).thenReturn(validRequestResponse);
    }

    @Test
    void getFizzBuzzList() {
        assertArrayEquals(invalidInt1Response.result().toArray(), fizzBuzzController.getFizzBuzzList(invalidInt1).getBody().result().toArray());
        assertEquals(HttpStatusCode.valueOf(400), fizzBuzzController.getFizzBuzzList(invalidInt1).getStatusCode());

        assertArrayEquals(invalidInt2Response.result().toArray(), fizzBuzzController.getFizzBuzzList(invalidInt2).getBody().result().toArray());
        assertEquals(HttpStatusCode.valueOf(400), fizzBuzzController.getFizzBuzzList(invalidInt2).getStatusCode());

        assertArrayEquals(invalidLimitResponse.result().toArray(), fizzBuzzController.getFizzBuzzList(invalidLimit).getBody().result().toArray());
        assertEquals(HttpStatusCode.valueOf(400), fizzBuzzController.getFizzBuzzList(invalidLimit).getStatusCode());

        assertArrayEquals(invalidStr1Response.result().toArray(), fizzBuzzController.getFizzBuzzList(invalidStr1).getBody().result().toArray());
        assertEquals(HttpStatusCode.valueOf(400), fizzBuzzController.getFizzBuzzList(invalidStr1).getStatusCode());

        assertArrayEquals(invalidStr2Response.result().toArray(), fizzBuzzController.getFizzBuzzList(invalidStr2).getBody().result().toArray());
        assertEquals(HttpStatusCode.valueOf(400), fizzBuzzController.getFizzBuzzList(invalidStr2).getStatusCode());

        assertArrayEquals(allInvalidResponse.result().toArray(), fizzBuzzController.getFizzBuzzList(allInvalid).getBody().result().toArray());
        assertEquals(HttpStatusCode.valueOf(400), fizzBuzzController.getFizzBuzzList(allInvalid).getStatusCode());

        assertEquals(validRequestResponse, fizzBuzzController.getFizzBuzzList(valid).getBody());
        assertEquals(HttpStatusCode.valueOf(200), fizzBuzzController.getFizzBuzzList(valid).getStatusCode());

    }

    @Test
    void getFizzBuzzStats() {
        when(fizzBuzzService.getMostUsed()).thenReturn(null);
        assertEquals(HttpStatusCode.valueOf(204), fizzBuzzController.getFizzBuzzStats().getStatusCode());
        when(fizzBuzzService.getMostUsed()).thenReturn(validStatsResponse);
        assertEquals(validStatsResponse, fizzBuzzController.getFizzBuzzStats().getBody());
        assertEquals(HttpStatusCode.valueOf(200), fizzBuzzController.getFizzBuzzStats().getStatusCode());

    }
}